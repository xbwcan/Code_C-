#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<pthread.h>
#include<windows.h>
double x[100], y[100];
void *generate_random(void *args)
{
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 100;i++)
    {
        
        x[i] = -1.0 + (double)((double)(rand() % 20) / 10.0);
        y[i] = -1.0 + (double)((double)(rand() % 20) / 10.0);
        //Sleep(1000);
    }
}
int main()
{
    freopen("pi.txt", "w", stdout);
    double pi;
    int num = 0;
    pthread_t tid;
    int ret = pthread_create(&tid, NULL, generate_random, NULL);
    if(ret!=0)
    {
        printf("Warning!");
    }
    pthread_join( tid, NULL );
    //pthread_exit(NULL);
    for (int i = 0; i < 100;i++)
    {
        if(x[i]*x[i]+y[i]*y[i]<1.0)
            num++;
    }
    pi = 4.0*(double)num / 100.0;
    printf("%lf\n", pi);
    for (int i = 0; i < 100;i++)
        printf("%lf %lf\n", x[i], y[i]);

    return 0;
}